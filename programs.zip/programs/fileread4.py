#- using csv library
import csv
try:
    with open("realestate.csv","r") as fobj:
        # convert fobj to csv object
        reader = csv.reader(fobj)
        for line in reader:
            print(line)
    val = 3 + "hello"
except Exception as err:
    print(err)   
    print("file not found.. please check")         
            
    