book  = {"chap1":10 ,"chap2":20 ,"chap3": 30}




print(book)

# display individual values
print(book["chap1"])  # 10
print(book["chap2"])  # 20

#add new key:value pair

book["chap4"] = 40
book["chap5"] = 50
#book["chap1"] = 1000
print(book)
# keys
print(list(book.keys()))
print(tuple(book.keys()))

for key in book.keys():
    print(key)
    
    
#values
print(book.values())

for value in book.values():
    print(value)
    
print(book.items())
# key and value
for key,value in book.items():
    print(key,value)
    
    
print(book["chap8"])


if "chap8" in book:
    print(book["chap8"])
else:
    print("chap8 doesn't exist")






# remove key:value from the dictionary
if "chap1" in book:
    book.pop("chap1")
    print("After removing :", book)

# remove some key:value pair
print(book)
book.popitem()

book  = {"chap1":10 ,"chap2":20 ,"chap3": 30}
newbook = {"chap7":70, "chap8":80}


#finalbook = book + newbook
#print(finalbook)
finalbook = {**book,**newbook}
print(finalbook)

# other way
# all the key:values of newbook will be updated to book
book.update(newbook)
print(book)
print(newbook)









