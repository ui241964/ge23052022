
# reading line by line
# fobj acts like file cursor or  file pointer
with open("languages.txt","r") as fobj:
    print(fobj)
    for line in fobj:
        #remove whitespaces if any
        line = line.strip()
        print(line)
    
    
    
    

# using readlines()
with open("languages.txt","r") as fobj:
    print(fobj.readlines())
    
    
with open("languages.txt","r") as fobj:
    for line in fobj.readlines():
        print(line)
        
        
# using read() -----> will return the string
with open("languages.txt","r") as fobj:
    print(fobj.read())
    
    
    
    
#- using csv library
import csv
with open("languages.txt","r") as fobj:
    # convert fobj to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
    
    
    
# using pandas

import pandas
data = pandas.read_csv('languages.txt')
print(data)
    
    
    
    
    

city=set()
#- using csv library
import csv
with open("realestate.csv","r") as fobj:
    # convert fobj to csv object
    reader = csv.DictReader(fobj)
    #print(reader)
    for line in reader:
        city.add(line["city"])
for x in city:
    print(x)    
    


city=set()
#- using csv library
import csv
with open("realestate.csv","r") as fobj:
    # convert fobj to csv object
    reader = csv.reader(fobj)
    #print(reader)
    for line in reader:
        city.add(line[1])
for x in city:
    print(x)    
    





citydict=dict()
#- using csv library
import csv
with open("realestate.csv","r") as fobj:
    # convert fobj to csv object
    reader = csv.reader(fobj)
    #print(reader)
    for line in reader:
        city in line[1]
        if city in citydict:
            citydict[city] +=1
        else:
            citydict[city] = 1
for x in citydict:
    print(x)    
    



#write a program to read realestate.csv and replace all the lines containing SACRAMENTO with BANGALORE and write
#the output to BANGALORE_info.csv



import csv
with open('files/realestate.csv', newline='') as csvfile:
    reader = csv.reader(csvfile)
    writer = csv.writer(open('BANGALORE_info1.csv', 'w',newline=''))
    for row in reader:
        if(row[1]=='SACRAMENTO'):
            row[1] = 'BANGALORE'
        writer.writerow(row)






    