

#

import pymysql

try:
    #step1
    db = pymysql.connect(host = '127.0.0.1',port=3306,user='root',password='india@123',database='ge')
    print(db)
    # cursor is used to navigate the records  --- just like fobj in file handling
    cursor = db.cursor()
    #step 2 # prepare your query
    query  = "insert into realestate values('{}','{}')".format("GT Road","Chennai")
    # step3 execute query
    cursor.execute(query)
    #step4  fetch output
    print(cursor.rowcount,"record inserted")
    db.commit()
    
    
    query = "select * from realestate"
    cursor.execute(query)
    #step4  fetch output
    for record in cursor.fetchall():
       print("Street  :",record[0])
       print("City    :",record[1])
       print("----------------")    
    db.close()

    
    
except pymysql.err.IntegrityError as err:
    print(err)
    print("Error related to primary key or foreign key")
except pymysql.err.DataError as err:
    print(err)
except Exception as err:
    print(err)

