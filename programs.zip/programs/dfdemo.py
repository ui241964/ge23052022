


import pandas


data = pandas.read_csv('data.csv')

print(data)
print(type(data))


