

# regular style  # traditional style
fobj = open("data1.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")
fobj.close()


fobj = open("data.txt","a")
fobj.write("c programming\n")
fobj.write("java programming\n")
fobj.close()



fw = open("numbers.txt","w")
for val in range(1,10):
    fw.write(str(val) + "\n")
fw.close()


#fobj = open(r"D:\new\new\data.txt","w")   # raw string
#fobj = open("D:/new/new/data.txt","w")

fobj = open("D:\\new\\new\\data.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")
fobj.close()






# pythonic way
# context manager
# if any line starts with keyword with .. we can it as context manager
# file gets closed automatically when it comes out of context
with open("data2.txt","w") as fobj:
    fobj.write("python programming\n")
    fobj.write("scala programming\n")
    


















