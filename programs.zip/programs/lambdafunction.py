

# regular function
# fixed arguments
def display(a,b):
    c = a + b
    return c

# calling function
total = display(10,20)
print(total)
###############################################################

#lambda :  anonymous function or   functionless or nameless function or inline function
#lambda is the replacemnt of single liner function
# Instead of writing single liner function lambda can be used

#syntax
#functioname = lambda variables : expression

display = lambda x,y : x+y
# calling function
total = display(10,20)
print(total)


#input
alist = ['google','microsoft','salesforce']

#output
['www.google.com','www.microsoft.com','www.salesforce.com']




#method1
alist = ['google','microsoft','salesforce']
blist = []
for item in alist:
    blist.append('www.'+item+'.com')
print(blist)    
    

# map(function,iterable)
#method2
alist = ['google','microsoft','salesforce']
def increment(x):
    return 'www.'+x+'.com'
print(list(map(increment,alist)))


#method3
alist = ['google','microsoft','salesforce']
increment = lambda x :'www.'+x+'.com'
print(list(map(increment,alist)))




#method4
alist = ['google','microsoft','salesforce']
print(list(map(lambda x :'www.'+x+'.com',alist)))
print(tuple(map(lambda x :'www.'+x+'.com',alist)))



alist = ['1','2','3','4']
print(list(map(lambda x :int(x),alist)))
print(list(map(int,alist)))


# map(function,iterable)










alist = ['google','microsoft','salesforce']

for item in alist:
    print('www.'+item+'.com',end=' ')




####################### filter() ##########################
values = [1,2,3,4,5,6,7]
print(list(filter(lambda x: x %2==0 , values)))
print(list(filter(lambda x: x %2 , values)))



alists = ["unix","perl","java","python"]

print(list(filter(lambda x: len(x) == 4 , alists)))





mytest = lambda x : True if ( x >10 and x <20) else False
print(mytest(12))




mytest = lambda x : "even" if ( x % 2 ==0) else 'Odd'
print(mytest(12))

















