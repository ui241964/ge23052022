
# keyword arguments

def display(c,a,b):
    print(a,b,c)


display(a=10 ,b=20,c=30)



print(10,20,sep=",",end="\n\n")

print(10,20,end="\n\n",sep=",")