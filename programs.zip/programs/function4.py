
# if any object starts with keyword * ... we call it as tuple

def display(*args):
    print(args)
    for val in args:
        print(val)
    
display(10,20,30,40,50)




## if any object is prefixed with ** .. we can it dictionary


def display(**kwargs):
    #print(kwargs)
    for k,v in kwargs.items():
        print(k,v)

display(a=10,b=20)



