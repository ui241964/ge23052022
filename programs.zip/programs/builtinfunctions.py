


val = int(input("Enter any value"))
print(val)
print(type(val))


name = input("Enter any string :")
print(name)


alist = [10,20,30]
print(type(alist))

print(isinstance(alist,list))
print(isinstance(alist,dict))
print(isinstance(alist,str))

if isinstance(alist,list):
    print("do something")
    
    
print(max(alist))
print(min(alist))
print(sum(alist))



print(id(alist))
blist = [120]
print(id(blist))







