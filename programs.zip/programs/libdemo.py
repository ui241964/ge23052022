

## importing all the methods
# all the methods will be imported to your programspace
import math
print(math.log(2))
print(math.tan(1))
print(math.floor(34.3))


#importing with alias
import math as m
print(m.log(2))
print(m.tan(1))
print(m.floor(34.3))
#print(math.tan(3))


# importing the required methods ONLY
# since we are importing required methods,  . is not required
from math import log,cos,ceil
print(log(3))
print(cos(1))











