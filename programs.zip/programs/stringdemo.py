
val = 10
print(val)
print("the value is ",val)

name = "python programming"
print(name)
print("I love",name)

# slicing
#string[start:stop:step]      # default step value is 1
print(name)
print(name[0])
print(name[1])
print(name[0:4])
print(name[0:10])
print(name[4:9])
print(name[0:18])
print(name[0:18:1])
print(name[0:18:2])
print(name[1:18:2])
print(name[0:14:3])
print(name[::4])
print(name[::])
print(name[:])
print(name[-1])
print(name[-2])
print(name[-5:-1])

print(name[::-1])
print(name[::-2])



name = "python programming"


print(name.startswith("p"))
print(name.endswith("q"))
print(name.endswith("g"))


print(name.isupper())
print(name.islower())


print(name.count("p"))  # 2 times
print(name.replace("python","scala"))


# if existing.. it returns the index position
# if not existing..it returns -1
print(name.find("prog"))  


aname = " python  "
print(len(aname))
print(len(aname.strip()))   # will remove whitespaces at both ends
print(len(aname.lstrip()))
print(len(aname.rstrip()))


print(name.capitalize())

print(name.title())


# template # which can be reused
bname = "I love {} and {}"
print(bname.format("python","scala"))
print(bname.format(1,2))
print(bname.format("unix","java"))



print(name.startswith("p"))
print(name.endswith("q"))
print(name.endswith("g"))



a = 10
b = 20
if a < b:
    print("do something")
    print("Inside if")
    print("still inside if")
print("regular program")






b = 20
if a < b:
    print("do something")
    print("Inside if")
    print("still inside if")
else:
    print("A is greater than B")
    print("inside else")
    print("still inside else")    
    
    

name  = "python"
if name.startswith("pyt"):
    print("its python programming")
elif name.startswith("spa"):
    print("its spark")
elif name.startswith("sca"):
    print("Its scala")
else:
    print("Its something else")
    
    



for i in range(1,11):
    print(i)
    
    
    
   
# range(start,stop,step)
for val in range(1,11,2):
    print(val)
    
for val in range(2,11,2):
    print(val)
    
    
for val in range(10,0,-1):
    print(val)
    
    
upper = 10
# range(start,stop,step)
for val in range(1,upper + 1):
    print(val)
    
    


name = "python"
for char in name:
    print(char)
    
    
name = "python"
for char in name[::-1]:
    print(char)
    
    
    
name = "python"
for char in name[::-1]:
    print(char)
    

name = "python"
for char in name[::-1]:
    print(char,end=" ")

    
    
    
    
    
    
    
    
    
    
    


name = "python"
name = "zython"
#name[0] = "z"

print(name)




























