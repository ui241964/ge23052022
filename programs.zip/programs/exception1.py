


import csv
try:
    with open("realestate.csv","r") as fobj:
        # convert fobj to csv object
        reader = csv.reader(fobj)
        for line in reader:
            print(line)
    val = 3 + "hello"
except FileNotFoundError as err:
    print(err)   
    print("file not found.. please check")         
except TypeError as err:
    print("Invalid operation")
    print(err)
except (IndexError,KeyError) as err:
    print(err)
    print("Invalid key or index found")
except Exception as err:
    print(err)
