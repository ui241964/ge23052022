# fname, mname,lname,dob,gender

# [ [emp1],[emp2],[emp3]  ]
  

# [ (emp1) , (emp2) , (emp3) ]



alist = [10,20,30,50,12,34,45]
alist[0] = 100
print("After replacing :",alist)




atup = (45,56,43,56,90)
atup[0] = 10000
print("After replacing", atup)


# convert tuple to list
alist = list(atup)
#adding something
alist.append(100)
# recoverting back to tuple
atup = tuple(alist)
print(atup)



alist = [12,5,21,54,7]
# list.append(singleobject)

alist.append(900)
print(alist)

print('After appending :',alist)
alist.append(87)
print('After appending :',alist)

# alist.extend() ---> multiple values
alist.extend([76,32,2])
print('after extending :',alist)

#list.insert(index,value)
alist.insert(1,1000)
print('After insertinng :',alist)


# list.pop()
alist.pop()
print("After pop :",alist)

alist.pop(1)
print("After pop :",alist)




print(alist)
#alist.remove(3000)
print("After removing :",alist)


if 3000 in alist:
    alist.remove(3000)
    print("After removing :",alist)
else:
    print("value doesn't exist")



getcount = alist.count(10)
print(getcount)
print(getcount)
if getcount > 0:
    alist.remove(3000)
    print("After removing :",alist)
else:
    print("value doesn't exist")


getcount =alist.count(10)
print(getcount)




alist = [10,10,10,10,30,40]

getcount = alist.count(10)
print(getcount)

for val in range(0,getcount):
    alist.remove(10)
print(alist)



print(alist)

# list.reverse()
alist.reverse()
print('After reversing :', alist)


alist.sort()
print('After sorting :', alist)

alist.sort(reverse = True)
print('After sorting :', alist)



















